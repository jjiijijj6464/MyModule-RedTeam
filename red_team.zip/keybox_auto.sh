#!/system/bin/sh

MODDIR="/data/adb/modules/red_team"
TARGET_DIR="/data/adb/tricky_store"
LOGS_DIR="/data/adb/red_team_logs"
LOG_FILE="$LOGS_DIR/keybox_auto.log"
INTERVAL=60
SOURCE_URL="https://raw.githubusercontent.com/jjiijijj6464/MyModule-RedTeam/main/conf"

log_message() {
    echo "[$(date '+%Y-%m-%d %H:%M:%S')] $1" >> "$LOG_FILE"
}

update_keybox() {
    log_message "=== Проверка обновлений keybox ==="
    
    if [ ! -d "$TARGET_DIR" ]; then
        mkdir -p "$TARGET_DIR"
        chmod 755 "$TARGET_DIR"
        chown 0:0 "$TARGET_DIR"
        log_message "Создана директория $TARGET_DIR"
    fi
    
    # Проверка интернета
    log_message "🌐 Проверка интернета..."
    if command -v ping >/dev/null 2>&1; then
        if ping -c 1 -W 2 8.8.8.8 >/dev/null 2>&1; then
            log_message "✅ Интернет есть (ping)"
        else
            log_message "⚠️ Ping не работает, пробуем curl..."
        fi
    fi
    
    if command -v curl >/dev/null 2>&1; then
        if curl -s --connect-timeout 5 https://raw.githubusercontent.com >/dev/null 2>&1; then
            log_message "✅ GitHub доступен (curl)"
        else
            log_message "⚠️ GitHub не отвечает на curl"
        fi
    fi
    
    TEMP_FILE="$TARGET_DIR/keybox.xml.temp"
    
    log_message "📥 Скачивание с $SOURCE_URL"
    
    # Пробуем curl с подробным выводом в лог
    if command -v curl >/dev/null 2>&1; then
        log_message "🔧 Использую curl..."
        curl -L --connect-timeout 10 --max-time 30 -v "$SOURCE_URL" -o "$TEMP_FILE" >> "$LOG_FILE" 2>&1
        CURL_EXIT=$?
        log_message "curl exit code: $CURL_EXIT"
        
        if [ $CURL_EXIT -ne 0 ]; then
            log_message "❌ curl завершился с ошибкой (код: $CURL_EXIT)"
        fi
    elif command -v wget >/dev/null 2>&1; then
        log_message "🔧 Использую wget..."
        wget --timeout=10 --tries=2 -v "$SOURCE_URL" -O "$TEMP_FILE" >> "$LOG_FILE" 2>&1
        WGET_EXIT=$?
        log_message "wget exit code: $WGET_EXIT"
        
        if [ $WGET_EXIT -ne 0 ]; then
            log_message "❌ wget завершился с ошибкой (код: $WGET_EXIT)"
        fi
    elif command -v toybox >/dev/null 2>&1; then
        log_message "🔧 Использую toybox wget..."
        toybox wget --timeout=10 "$SOURCE_URL" -O "$TEMP_FILE" >> "$LOG_FILE" 2>&1
        TOYBOX_EXIT=$?
        log_message "toybox exit code: $TOYBOX_EXIT"
        
        if [ $TOYBOX_EXIT -ne 0 ]; then
            log_message "❌ toybox завершился с ошибкой (код: $TOYBOX_EXIT)"
        fi
    else
        log_message "❌ ОШИБКА: нет curl/wget/toybox"
        return 1
    fi
    
    # Проверяем результат
    if [ -f "$TEMP_FILE" ]; then
        FILE_SIZE=$(wc -c < "$TEMP_FILE")
        log_message "📊 Файл создан, размер: $FILE_SIZE байт"
        
        if [ "$FILE_SIZE" -gt 0 ]; then
            log_message "✅ Файл скачан успешно!"
        else
            log_message "❌ Файл пустой!"
            rm -f "$TEMP_FILE"
            return 1
        fi
    else
        log_message "❌ Файл НЕ создан!"
        return 1
    fi
    
    log_message "✅ Файл скачан (размер: $(wc -c < "$TEMP_FILE") байт)"
    
    log_message "🔓 Декодирование base64..."
    
    DECODED_FILE="$TARGET_DIR/keybox.xml.decoded"
    
    if command -v base64 >/dev/null 2>&1; then
        base64 -d "$TEMP_FILE" > "$DECODED_FILE" 2>/dev/null
        DECODE_RESULT=$?
        log_message "base64 exit code: $DECODE_RESULT"
        
        if [ $DECODE_RESULT -ne 0 ]; then
            log_message "❌ Ошибка декодирования base64 (код: $DECODE_RESULT)"
            rm -f "$TEMP_FILE" "$DECODED_FILE"
            return 1
        fi
    else
        log_message "❌ base64 не найден!"
        rm -f "$TEMP_FILE"
        return 1
    fi
    
    if [ ! -f "$DECODED_FILE" ] || [ ! -s "$DECODED_FILE" ]; then
        log_message "❌ Декодированный файл пустой!"
        rm -f "$TEMP_FILE" "$DECODED_FILE"
        return 1
    fi
    
    log_message "✅ Декодировано (размер: $(wc -c < "$DECODED_FILE") байт)"
    
    if ! head -c 100 "$DECODED_FILE" | grep -q "<?xml\|<Keybox"; then
        log_message "⚠️ Файл не похож на XML, пробуем двойное декодирование..."
        DOUBLE_DECODED="$TARGET_DIR/keybox.xml.double"
        base64 -d "$DECODED_FILE" > "$DOUBLE_DECODED" 2>/dev/null
        if [ $? -eq 0 ] && [ -s "$DOUBLE_DECODED" ] && head -c 100 "$DOUBLE_DECODED" | grep -q "<?xml\|<Keybox"; then
            log_message "✅ Двойное декодирование успешно"
            mv "$DOUBLE_DECODED" "$DECODED_FILE"
        else
            rm -f "$DOUBLE_DECODED"
        fi
    fi
    
    if [ -f "$TARGET_DIR/keybox.xml" ]; then
        if cmp -s "$DECODED_FILE" "$TARGET_DIR/keybox.xml" 2>/dev/null; then
            log_message "✅ Keybox актуален (без изменений)"
            rm -f "$TEMP_FILE" "$DECODED_FILE"
            return 0
        fi
    fi
    
    log_message "🆕 Обнаружен новый keybox!"
    
    if [ -f "$TARGET_DIR/keybox.xml" ]; then
        cp "$TARGET_DIR/keybox.xml" "$TARGET_DIR/keybox.xml.bak"
        log_message "💾 Бэкап создан: keybox.xml.bak"
    fi
    
    mv "$DECODED_FILE" "$TARGET_DIR/keybox.xml"
    chmod 644 "$TARGET_DIR/keybox.xml"
    chown 0:0 "$TARGET_DIR/keybox.xml"
    
    log_message "✅ Keybox установлен (размер: $(wc -c < "$TARGET_DIR/keybox.xml") байт)"
    
    rm -f "$TEMP_FILE"
    
    log_message "🔄 Перезапуск Google сервисов..."
    for pkg in com.android.vending com.google.android.gms com.google.android.gsf; do
        am force-stop "$pkg" 2>/dev/null
        for pid in $(pgrep -f "$pkg" 2>/dev/null); do
            kill -9 "$pid" 2>/dev/null
        done
    done
    
    log_message "✅ Keybox успешно обновлён!"
    return 0
}

main_loop() {
    log_message "🚀 Демон автообновления запущен (интервал: ${INTERVAL}с)"
    update_keybox
    while true; do
        sleep $INTERVAL
        update_keybox
    done
}

case "$1" in
    --once)
        update_keybox
        ;;
    --daemon)
        main_loop
        ;;
    *)
        nohup $0 --daemon > /dev/null 2>&1 &
        ;;
esac