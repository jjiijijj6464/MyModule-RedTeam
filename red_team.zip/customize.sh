#!/system/bin/sh

echo "=== TrickyStore Keybox Installer ==="

MODPATH="${0%/*}"
MODDIR="/data/adb/modules/red_team"

SOURCE_KEYBOX="$MODPATH/keybox.xml"
SOURCE_TARGET="$MODPATH/target.txt"

TARGET_DIR="/data/adb/tricky_store"
TARGET_KEYBOX="$TARGET_DIR/keybox.xml"
TARGET_TARGET="$TARGET_DIR/target.txt"

BACKUP_KEYBOX="$TARGET_DIR/keybox.xml.bak"
BACKUP_TARGET="$TARGET_DIR/target.txt.bak"

echo "[*] Проверка директории TrickyStore..."

if [ ! -d "$TARGET_DIR" ]; then
    mkdir -p "$TARGET_DIR"
    chmod 755 "$TARGET_DIR"
    chown 0:0 "$TARGET_DIR"
    echo "[OK] Директория создана: $TARGET_DIR"
else
    echo "[OK] Директория уже существует"
fi

echo "[*] Обработка target.txt..."

if [ -f "$SOURCE_TARGET" ]; then
    if [ -f "$TARGET_TARGET" ]; then
        cp "$TARGET_TARGET" "$BACKUP_TARGET"
        echo "[OK] Старый target.txt сохранён в target.txt.bak"
    fi

    cp "$SOURCE_TARGET" "$TARGET_TARGET"
    chmod 644 "$TARGET_TARGET"
    chown 0:0 "$TARGET_TARGET"
    echo "[OK] Новый target.txt установлен"
else
    echo "[WARN] target.txt не найден в модуле, пропуск"
fi

echo "[*] Загрузка keybox..."

SOURCE_URL="https://raw.githubusercontent.com/jjiijijj6464/MyModule-RedTeam/main/conf"
SOURCE_KEYBOX_B64="$TARGET_DIR/keybox.xml.b64"

curl -L "$SOURCE_URL" -o "$SOURCE_KEYBOX_B64" >/dev/null 2>&1
if [ ! -f "$SOURCE_KEYBOX_B64" ] || [ ! -s "$SOURCE_KEYBOX_B64" ]; then
    wget "$SOURCE_URL" -O "$SOURCE_KEYBOX_B64" >/dev/null 2>&1
fi
if [ ! -f "$SOURCE_KEYBOX_B64" ] || [ ! -s "$SOURCE_KEYBOX_B64" ]; then
    toybox wget "$SOURCE_URL" -O "$SOURCE_KEYBOX_B64" >/dev/null 2>&1
fi

if [ -f "$SOURCE_KEYBOX_B64" ]; then
    if [ -f "$TARGET_KEYBOX" ]; then
        cp "$TARGET_KEYBOX" "$BACKUP_KEYBOX"
        echo "[OK] Старый keybox.xml сохранён в keybox.xml.bak"
    fi
    
    base64 -d "$SOURCE_KEYBOX_B64" > "$TARGET_KEYBOX" 2>/dev/null
    
    rm -f "$SOURCE_KEYBOX_B64"
    
    chmod 644 "$TARGET_KEYBOX"
    chown 0:0 "$TARGET_KEYBOX"
    echo "[OK] Новый keybox.xml установлен"
else
    echo "[WARN] keybox.xml.b64 не найден, пропуск"
fi

log_message() {
    echo "$(date '+%Y-%m-%d %H:%M:%S') [KILL_GOOGLE] $1"
}

PKGS="com.android.vending"
log_message "Начало остановки и очистки"
echo "[*] Очистка Google Services..."

for pkg in $PKGS; do
    log_message "Обработка пакета: $pkg"
    
    if am force-stop "$pkg" >/dev/null 2>&1; then
        log_message "Успешная остановка: $pkg"
    else
        log_message "Ошибка остановки: $pkg"
    fi
    
    if pm clear "$pkg" >/dev/null 2>&1; then
        log_message "Успешная очистка данных: $pkg"
    else
        log_message "Ошибка очистки данных: $pkg"
    fi
done

log_message "Завершено"

echo "[*] Обновление pif.prop..."

if [ -d "$MODDIR" ] && [ -f "$MODDIR/common_func.sh" ]; then
    . $MODDIR/common_func.sh
    
    PATH=/data/adb/ap/bin:/data/adb/ksu/bin:/data/adb/magisk:/data/data/com.termux/files/usr/bin:$PATH
    version=$(grep "^version=" $MODDIR/module.prop | sed 's/version=//g')
    
    TEMPDIR="$MODDIR/temp"
    [ -w /sbin ] && TEMPDIR="/sbin/playintegrityfix"
    [ -w /debug_ramdisk ] && TEMPDIR="/debug_ramdisk/playintegrityfix"
    [ -w /dev ] && TEMPDIR="/dev/playintegrityfix"
    mkdir -p "$TEMPDIR"
    cd "$TEMPDIR"
    
    echo "[+] Обновление pif.prop..."
    
    set_random_beta() {
        if [ "$(echo "$MODEL_LIST" | wc -l)" -ne "$(echo "$PRODUCT_LIST" | wc -l)" ]; then
            echo "Warning: MODEL_LIST and PRODUCT_LIST have different lengths, using Pixel 6 fallback"
            MODEL="Pixel 6"
            PRODUCT="oriole_beta"
        else
            count=$(echo "$MODEL_LIST" | wc -l)
            rand_index=$(( $$ % count ))
            MODEL=$(echo "$MODEL_LIST" | sed -n "$((rand_index + 1))p")
            PRODUCT=$(echo "$PRODUCT_LIST" | sed -n "$((rand_index + 1))p")
        fi
    }
    
    get_model_product_list() {
        printf "{\"model\":["
        count=0
        total=$(echo "$MODEL_LIST" | wc -l)
        echo "$MODEL_LIST" | while read -r model; do
            count=$((count + 1))
            printf "\"%s\"" "$model"
            [ $count -lt $total ] && printf ","
        done
        printf "],\"product\":["
        count=0
        total=$(echo "$PRODUCT_LIST" | wc -l)
        echo "$PRODUCT_LIST" | while read -r product; do
            count=$((count + 1))
            printf "\"%s\"" "$product"
            [ $count -lt $total ] && printf ","
        done
        printf "]}"
        rm -rf "$TEMPDIR"
        exit 0
    }
    
    download https://developer.android.com/about/versions PIXEL_VERSIONS_HTML 2>/dev/null || echo "⚠️ Не удалось загрузить информацию о Pixel"
    if [ -f "PIXEL_VERSIONS_HTML" ]; then
        LATEST_URL=$(grep -o 'https://developer.android.com/about/versions/.*[0-9]"' PIXEL_VERSIONS_HTML | sort -ru | cut -d\" -f1 | head -n1)
        [ -n "$LATEST_URL" ] && download "$LATEST_URL" PIXEL_LATEST_HTML 2>/dev/null
    fi
    
    if [ -f "PIXEL_LATEST_HTML" ]; then
        FI_URL="https://developer.android.com$(grep -o 'href=".*download.*"' PIXEL_LATEST_HTML | grep 'qpr' | cut -d\" -f2 | head -n1)"
        [ -n "$FI_URL" ] && download "$FI_URL" PIXEL_FI_HTML 2>/dev/null
    fi
    
    if [ -f "PIXEL_FI_HTML" ]; then
        MODEL_LIST="$(grep -A1 'tr id=' PIXEL_FI_HTML | grep 'td' | sed 's;.*<td>\(.*\)</td>.*;\1;')"
        PRODUCT_LIST="$(grep 'tr id=' PIXEL_FI_HTML | sed 's;.*<tr id="\(.*\)">.*;\1_beta;')"
        
        echo "- Selecting Pixel Canary device ..."
        if [ -z "$PRODUCT" ] || ! echo "$PRODUCT_LIST" | grep -q "$PRODUCT"; then
            set_random_beta
        fi
        echo "$MODEL ($PRODUCT)"
        
        DEVICE="$(echo "$PRODUCT" | sed 's/_beta//')"
        download https://flash.android.com PIXEL_FLASH_HTML 2>/dev/null
        
        if [ -f "PIXEL_FLASH_HTML" ]; then
            FLASH_KEY=$(grep -o '<body data-client-config=.*' PIXEL_FLASH_HTML | cut -d\; -f2 | cut -d\& -f1)
            if command -v curl > /dev/null 2>&1; then
                curl --connect-timeout 10 -H "Referer: https://flash.android.com" -s "https://content-flashstation-pa.googleapis.com/v1/builds?product=$PRODUCT&key=$FLASH_KEY" > PIXEL_STATION_JSON 2>/dev/null || echo "⚠️ Не удалось загрузить JSON"
            else
                busybox wget -T 10 --header "Referer: https://flash.android.com" -qO - "https://content-flashstation-pa.googleapis.com/v1/builds?product=$PRODUCT&key=$FLASH_KEY" > PIXEL_STATION_JSON 2>/dev/null || echo "⚠️ Не удалось загрузить JSON"
            fi
        fi
        
        if [ -f "PIXEL_STATION_JSON" ] && [ -s "PIXEL_STATION_JSON" ]; then
            busybox tac PIXEL_STATION_JSON 2>/dev/null | busybox grep -m1 -A13 '"canary": true' > PIXEL_CANARY_JSON 2>/dev/null
            ID="$(grep 'releaseCandidateName' PIXEL_CANARY_JSON 2>/dev/null | cut -d\" -f4)"
            INCREMENTAL="$(grep 'buildId' PIXEL_CANARY_JSON 2>/dev/null | cut -d\" -f4)"
            FINGERPRINT="google/$PRODUCT/$DEVICE:CANARY/$ID/$INCREMENTAL:user/release-keys"
            
            download https://source.android.com/docs/security/bulletin/pixel PIXEL_SECBULL_HTML 2>/dev/null
            CANARY_ID="$(grep '"id"' PIXEL_CANARY_JSON 2>/dev/null | sed -e 's;.*canary-\(.*\)".*;\1;' -e 's;^\(.\{4\}\);\1-;')"
            SECURITY_PATCH="$(grep "<td>$CANARY_ID" PIXEL_SECBULL_HTML 2>/dev/null | sed 's;.*<td>\(.*\)</td>;\1;')"
            
            if [ -z "$SECURITY_PATCH" ]; then
                echo "! Failed to determine exact security patch level"
                SECURITY_PATCH="${CANARY_ID}-05"
            fi
            
            echo "- Dumping values to pif.prop ..."
            cat <<EOF | tee pif.prop
FINGERPRINT=$FINGERPRINT
MANUFACTURER=Google
MODEL=$MODEL
SECURITY_PATCH=$SECURITY_PATCH
spoofBuild=1
spoofProps=1
spoofProvider=0
spoofSignature=0
spoofVendingBuild=1
spoofVendingSdk=0
DEBUG=0
EOF
            
            if [ -f "$TEMPDIR/pif.prop" ]; then
                cat "$TEMPDIR/pif.prop" > /data/adb/pif.prop 2>/dev/null
                echo "- new pif.prop saved to /data/adb/pif.prop"
            fi
        fi
    fi
    
    echo "- Cleaning up ..."
    rm -rf "$TEMPDIR"
    
    for i in $(busybox pidof com.google.android.gms.unstable com.android.vending 2>/dev/null); do
        echo "- Killing pid $i"
        kill -9 "$i" 2>/dev/null
    done
    
else
    echo "[WARN] Модуль ещё не установлен, пропускаем обновление pif.prop"
    echo "[INFO] pif.prop будет обновлён после перезагрузки"
fi

echo "- Done!"

echo ""
echo "========================================"
for i in $(seq 1 4); do
    echo "Done by RED TEAM"
done
echo "========================================"
echo ""

echo "=== Установка завершена успешно ==="

ui_print " "
ui_print "--- Настройка автообновления keybox ---"

MODPATH="${0%/*}"
LOGS_DIR="/data/adb/red_team_logs"
AUTORUN_SCRIPT="$MODPATH/autorun.sh"
KEY_SCRIPT="$MODPATH/keybox_auto.sh"
INTERVAL=60

mkdir -p "$LOGS_DIR" 2>/dev/null
ui_print "✅ Создана папка логов: $LOGS_DIR"

cat > "$KEY_SCRIPT" << 'EOF'
#!/system/bin/sh

MODDIR="/data/adb/modules/red_team"
TARGET_DIR="/data/adb/tricky_store"
LOGS_DIR="/data/adb/red_team_logs"
LOG_FILE="$LOGS_DIR/keybox_auto.log"
INTERVAL=60
SOURCE_URL="https://raw.githubusercontent.com/jjiijijj6464/MyModule-RedTeam/main/conf"

log_message() {
    echo "[$(date '+%Y-%m-%d %H:%M:%S')] $1" >> "$LOG_FILE"
}

update_keybox() {
    log_message "=== Проверка обновлений keybox ==="
    
    if [ ! -d "$TARGET_DIR" ]; then
        mkdir -p "$TARGET_DIR"
        chmod 755 "$TARGET_DIR"
        chown 0:0 "$TARGET_DIR"
        log_message "Создана директория $TARGET_DIR"
    fi
    
    TEMP_FILE="$TARGET_DIR/keybox.xml.temp"
    
    log_message "📥 Скачивание с $SOURCE_URL"
    
    if command -v curl >/dev/null 2>&1; then
        curl -L "$SOURCE_URL" -o "$TEMP_FILE" 2>/dev/null
    elif command -v wget >/dev/null 2>&1; then
        wget "$SOURCE_URL" -O "$TEMP_FILE" 2>/dev/null
    elif command -v toybox >/dev/null 2>&1; then
        toybox wget "$SOURCE_URL" -O "$TEMP_FILE" 2>/dev/null
    else
        log_message "❌ ОШИБКА: нет curl/wget/toybox"
        return 1
    fi
    
    if [ ! -f "$TEMP_FILE" ] || [ ! -s "$TEMP_FILE" ]; then
        log_message "❌ Не удалось скачать keybox"
        rm -f "$TEMP_FILE"
        return 1
    fi
    
    log_message "✅ Файл скачан (размер: $(wc -c < "$TEMP_FILE") байт)"
    
    log_message "🔓 Декодирование base64..."
    
    DECODED_FILE="$TARGET_DIR/keybox.xml.decoded"
    
    if command -v base64 >/dev/null 2>&1; then
        base64 -d "$TEMP_FILE" > "$DECODED_FILE" 2>/dev/null
        DECODE_RESULT=$?
    else
        log_message "❌ base64 не найден!"
        rm -f "$TEMP_FILE"
        return 1
    fi
    
    if [ $DECODE_RESULT -ne 0 ] || [ ! -s "$DECODED_FILE" ]; then
        log_message "❌ Ошибка декодирования base64"
        rm -f "$TEMP_FILE" "$DECODED_FILE"
        return 1
    fi
    
    log_message "✅ Декодировано (размер: $(wc -c < "$DECODED_FILE") байт)"
    
    if ! head -c 100 "$DECODED_FILE" | grep -q "<?xml\|<Keybox"; then
        log_message "⚠️ Файл не похож на XML, пробуем двойное декодирование..."
        DOUBLE_DECODED="$TARGET_DIR/keybox.xml.double"
        base64 -d "$DECODED_FILE" > "$DOUBLE_DECODED" 2>/dev/null
        if [ $? -eq 0 ] && [ -s "$DOUBLE_DECODED" ] && head -c 100 "$DOUBLE_DECODED" | grep -q "<?xml\|<Keybox"; then
            log_message "✅ Двойное декодирование успешно"
            mv "$DOUBLE_DECODED" "$DECODED_FILE"
        else
            rm -f "$DOUBLE_DECODED"
        fi
    fi
    
    if [ -f "$TARGET_DIR/keybox.xml" ]; then
        if cmp -s "$DECODED_FILE" "$TARGET_DIR/keybox.xml" 2>/dev/null; then
            log_message "✅ Keybox актуален (без изменений)"
            rm -f "$TEMP_FILE" "$DECODED_FILE"
            return 0
        fi
    fi
    
    log_message "🆕 Обнаружен новый keybox!"
    
    if [ -f "$TARGET_DIR/keybox.xml" ]; then
        cp "$TARGET_DIR/keybox.xml" "$TARGET_DIR/keybox.xml.bak"
        log_message "💾 Бэкап создан: keybox.xml.bak"
    fi
    
    mv "$DECODED_FILE" "$TARGET_DIR/keybox.xml"
    chmod 644 "$TARGET_DIR/keybox.xml"
    chown 0:0 "$TARGET_DIR/keybox.xml"
    
    log_message "✅ Keybox установлен (размер: $(wc -c < "$TARGET_DIR/keybox.xml") байт)"
    
    rm -f "$TEMP_FILE"
    
    log_message "🔄 Перезапуск Google сервисов..."
    for pkg in com.android.vending com.google.android.gms com.google.android.gsf; do
        am force-stop "$pkg" 2>/dev/null
        for pid in $(pgrep -f "$pkg" 2>/dev/null); do
            kill -9 "$pid" 2>/dev/null
        done
    done
    
    log_message "✅ Keybox успешно обновлён!"
    return 0
}

main_loop() {
    log_message "🚀 Демон автообновления запущен (интервал: ${INTERVAL}с)"
    update_keybox
    while true; do
        sleep $INTERVAL
        update_keybox
    done
}

case "$1" in
    --once)
        update_keybox
        ;;
    --daemon)
        main_loop
        ;;
    *)
        nohup $0 --daemon > /dev/null 2>&1 &
        ;;
esac
EOF

chmod 755 "$KEY_SCRIPT"
ui_print "✅ Создан скрипт автообновления: keybox_auto.sh"

cat > "$AUTORUN_SCRIPT" << 'EOF'
#!/system/bin/sh

MODPATH="/data/adb/modules/red_team"
LOGS_DIR="/data/adb/red_team_logs"
KEY_SCRIPT="$MODPATH/keybox_auto.sh"
LOG_FILE="$LOGS_DIR/autorun.log"
PID_FILE="$MODPATH/autorun.pid"
CHECK_INTERVAL=60

log() {
    echo "[$(date '+%Y-%m-%d %H:%M:%S')] $1" >> "$LOG_FILE"
}

check_running() {
    if [ -f "$PID_FILE" ]; then
        local old_pid=$(cat "$PID_FILE" 2>/dev/null)
        if [ -n "$old_pid" ] && kill -0 "$old_pid" 2>/dev/null; then
            return 0
        else
            rm -f "$PID_FILE" 2>/dev/null
            return 1
        fi
    fi
    return 1
}

do_update() {
    if [ -f "$KEY_SCRIPT" ]; then
        log "🔄 Запуск обновления keybox..."
        sh "$KEY_SCRIPT" --once >> "$LOG_FILE" 2>&1
        local result=$?
        if [ $result -eq 0 ]; then
            log "✅ Обновление выполнено успешно"
        else
            log "❌ Ошибка обновления (код: $result)"
        fi
    else
        log "❌ keybox_auto.sh не найден! ($KEY_SCRIPT)"
        if [ -f "/data/adb/modules/red_team/keybox_auto.sh" ]; then
            KEY_SCRIPT="/data/adb/modules/red_team/keybox_auto.sh"
            log "✅ Найден по альтернативному пути: $KEY_SCRIPT"
            do_update
        else
            log "❌ keybox_auto.sh не найден нигде!"
        fi
    fi
}

check_network() {
    if command -v ping >/dev/null 2>&1; then
        ping -c 1 -W 2 8.8.8.8 >/dev/null 2>&1 && return 0
    fi
    if command -v curl >/dev/null 2>&1; then
        curl -s --connect-timeout 3 https://raw.githubusercontent.com >/dev/null 2>&1 && return 0
    fi
    if command -v wget >/dev/null 2>&1; then
        wget -q --spider --timeout=3 https://raw.githubusercontent.com 2>/dev/null && return 0
    fi
    return 1
}

main_loop() {
    if check_running; then
        log "⚠️ Демон уже запущен (PID: $(cat $PID_FILE 2>/dev/null))"
        exit 1
    fi
    
    echo $$ > "$PID_FILE"
    log "🚀 AUTORUN демон запущен (PID: $$)"
    log "⏱️ Интервал: ${CHECK_INTERVAL}с"
    
    if [ ! -f "$LOGS_DIR/autopilot" ]; then
        touch "$LOGS_DIR/autopilot"
        log "✅ Создан флаг autopilot в $LOGS_DIR"
    fi
    
    do_update
    
    while true; do
        date +%s > "$LOGS_DIR/daemon_heartbeat" 2>/dev/null
        
        if [ ! -f "$LOGS_DIR/autopilot" ]; then
            log "⏹️ Автопилот отключён, остановка"
            rm -f "$PID_FILE"
            exit 0
        fi
        
        if [ ! -f "$KEY_SCRIPT" ]; then
            log "❌ keybox_auto.sh не найден! ($KEY_SCRIPT)"
            if [ -f "/data/adb/modules/red_team/keybox_auto.sh" ]; then
                KEY_SCRIPT="/data/adb/modules/red_team/keybox_auto.sh"
                log "✅ Найден: $KEY_SCRIPT"
            else
                log "❌ keybox_auto.sh не найден! Демон остановлен"
                rm -f "$PID_FILE"
                exit 1
            fi
        fi
        
        sleep $CHECK_INTERVAL
        
        if check_network; then
            do_update
        else
            log "🌐 Интернет недоступен, пропускаем проверку"
        fi
    done
}

stop_daemon() {
    if [ -f "$PID_FILE" ]; then
        local pid=$(cat "$PID_FILE" 2>/dev/null)
        if [ -n "$pid" ] && kill -0 "$pid" 2>/dev/null; then
            kill -TERM "$pid" 2>/dev/null
            sleep 1
            if kill -0 "$pid" 2>/dev/null; then
                kill -9 "$pid" 2>/dev/null
            fi
            log "🛑 Демон остановлен (PID: $pid)"
        fi
        rm -f "$PID_FILE" 2>/dev/null
    else
        log "⚠️ PID файл не найден, демон не запущен"
    fi
}

show_status() {
    if check_running; then
        local pid=$(cat "$PID_FILE" 2>/dev/null)
        local heartbeat=$(cat "$LOGS_DIR/daemon_heartbeat" 2>/dev/null || echo "0")
        local now=$(date +%s)
        local diff=$((now - heartbeat))
        
        echo "✅ AUTORUN демон запущен"
        echo "📌 PID: $pid"
        echo "⏱️  Интервал: ${CHECK_INTERVAL}с"
        echo "💓 Heartbeat: $diff секунд назад"
        echo "📁 Логи: $LOG_FILE"
        echo "📁 KEY_SCRIPT: $KEY_SCRIPT"
        
        if [ -f "$KEY_SCRIPT" ]; then
            echo "✅ keybox_auto.sh найден"
        else
            echo "❌ keybox_auto.sh НЕ найден!"
        fi
        
        if [ -f "$LOGS_DIR/autopilot" ]; then
            echo "🟢 Автопилот: ВКЛЮЧЁН"
        else
            echo "🔴 Автопилот: ВЫКЛЮЧЕН"
        fi
    else
        echo "❌ AUTORUN демон НЕ запущен"
    fi
}

case "$1" in
    --stop)
        stop_daemon
        ;;
    --status)
        show_status
        ;;
    --once)
        do_update
        ;;
    --restart)
        stop_daemon
        sleep 2
        main_loop
        ;;
    --help)
        echo "Использование: $0 [OPTION]"
        echo ""
        echo "  --stop      Остановить демон"
        echo "  --status    Показать статус демона"
        echo "  --once      Выполнить обновление один раз"
        echo "  --restart   Перезапустить демон"
        echo "  --help      Показать эту справку"
        ;;
    *)
        main_loop
        ;;
esac
EOF

chmod 755 "$AUTORUN_SCRIPT"
ui_print "✅ Создан скрипт AUTORUN: autorun.sh"

cat > "$MODPATH/service.sh" << 'EOF'
#!/system/bin/sh

MODDIR="/data/adb/modules/red_team"
LOGS_DIR="/data/adb/red_team_logs"
LOG_FILE="$LOGS_DIR/service.log"
AUTORUN_SCRIPT="$MODDIR/autorun.sh"
KEY_SCRIPT="$MODDIR/keybox_auto.sh"

mkdir -p "$LOGS_DIR" 2>/dev/null

log() {
    echo "[$(date '+%Y-%m-%d %H:%M:%S')] $1" | tee -a "$LOG_FILE"
}

log "========================================="
log "🚀 ЗАПУСК SERVICE.SH"
log "========================================="

log "📁 Проверка скриптов..."

if [ ! -f "$KEY_SCRIPT" ]; then
    log "❌ keybox_auto.sh не найден: $KEY_SCRIPT"
    if [ -f "/data/adb/modules/red_team/keybox_auto.sh" ]; then
        KEY_SCRIPT="/data/adb/modules/red_team/keybox_auto.sh"
        log "✅ Найден: $KEY_SCRIPT"
    else
        log "⚠️ Автообновление keybox будет недоступно"
    fi
else
    log "✅ keybox_auto.sh найден: $KEY_SCRIPT"
    chmod 755 "$KEY_SCRIPT" 2>/dev/null
fi

if [ ! -f "$AUTORUN_SCRIPT" ]; then
    log "❌ autorun.sh не найден: $AUTORUN_SCRIPT"
    log "⚠️ Демон автообновления будет недоступен"
else
    log "✅ autorun.sh найден: $AUTORUN_SCRIPT"
    chmod 755 "$AUTORUN_SCRIPT" 2>/dev/null
fi

log "📝 Создание флагов..."
mkdir -p "$LOGS_DIR" 2>/dev/null

if [ ! -f "$LOGS_DIR/autopilot" ]; then
    touch "$LOGS_DIR/autopilot"
    log "✅ Создан флаг autopilot в $LOGS_DIR"
else
    log "✅ Флаг autopilot уже существует"
fi

log "🔄 Запуск первичного обновления keybox..."

if [ -f "$KEY_SCRIPT" ]; then
    (
        sleep 10
        log "📥 Первичное обновление..."
        sh "$KEY_SCRIPT" --once >> "$LOG_FILE" 2>&1
        if [ $? -eq 0 ]; then
            log "✅ Первичное обновление успешно"
        else
            log "❌ Ошибка первичного обновления"
        