#!/system/bin/sh

MODDIR="/data/adb/modules/red_team"
LOGS_DIR="/data/adb/red_team_logs"
LOG_FILE="$LOGS_DIR/service.log"
AUTORUN_SCRIPT="$MODDIR/autorun.sh"
KEY_SCRIPT="$MODDIR/keybox_auto.sh"

mkdir -p "$LOGS_DIR" 2>/dev/null

log() {
    echo "[$(date '+%Y-%m-%d %H:%M:%S')] $1" | tee -a "$LOG_FILE"
}

log "========================================="
log "🚀 ЗАПУСК SERVICE.SH"
log "========================================="

log "📁 Проверка скриптов..."

if [ ! -f "$KEY_SCRIPT" ]; then
    log "❌ keybox_auto.sh не найден: $KEY_SCRIPT"
    if [ -f "/data/adb/modules/red_team/keybox_auto.sh" ]; then
        KEY_SCRIPT="/data/adb/modules/red_team/keybox_auto.sh"
        log "✅ Найден: $KEY_SCRIPT"
    else
        log "⚠️ Автообновление keybox будет недоступно"
    fi
else
    log "✅ keybox_auto.sh найден: $KEY_SCRIPT"
    chmod 755 "$KEY_SCRIPT" 2>/dev/null
fi

if [ ! -f "$AUTORUN_SCRIPT" ]; then
    log "❌ autorun.sh не найден: $AUTORUN_SCRIPT"
    log "⚠️ Демон автообновления будет недоступен"
else
    log "✅ autorun.sh найден: $AUTORUN_SCRIPT"
    chmod 755 "$AUTORUN_SCRIPT" 2>/dev/null
fi

log "📝 Создание флагов..."
mkdir -p "$LOGS_DIR" 2>/dev/null

if [ ! -f "$LOGS_DIR/autopilot" ]; then
    touch "$LOGS_DIR/autopilot"
    log "✅ Создан флаг autopilot в $LOGS_DIR"
else
    log "✅ Флаг autopilot уже существует"
fi

log "🔄 Запуск первичного обновления keybox..."

if [ -f "$KEY_SCRIPT" ]; then
    (
        sleep 10
        log "📥 Первичное обновление..."
        sh "$KEY_SCRIPT" --once >> "$LOG_FILE" 2>&1
        if [ $? -eq 0 ]; then
            log "✅ Первичное обновление успешно"
        else
            log "❌ Ошибка первичного обновления"
        fi
    ) &
else
    log "⚠️ keybox_auto.sh не найден, пропускаем"
fi

log "🚀 Запуск AUTORUN демона..."

if [ -f "$AUTORUN_SCRIPT" ]; then
    if [ -f "$MODDIR/autorun.pid" ]; then
        OLD_PID=$(cat "$MODDIR/autorun.pid" 2>/dev/null)
        if [ -n "$OLD_PID" ] && kill -0 "$OLD_PID" 2>/dev/null; then
            log "⚠️ AUTORUN демон уже запущен (PID: $OLD_PID)"
        else
            rm -f "$MODDIR/autorun.pid" 2>/dev/null
            nohup sh "$AUTORUN_SCRIPT" >> "$LOG_FILE" 2>&1 &
            sleep 2
            if [ -f "$MODDIR/autorun.pid" ]; then
                NEW_PID=$(cat "$MODDIR/autorun.pid" 2>/dev/null)
                log "✅ AUTORUN демон запущен (PID: $NEW_PID)"
            else
                log "❌ Ошибка запуска AUTORUN демона"
            fi
        fi
    else
        nohup sh "$AUTORUN_SCRIPT" >> "$LOG_FILE" 2>&1 &
        sleep 2
        if [ -f "$MODDIR/autorun.pid" ]; then
            NEW_PID=$(cat "$MODDIR/autorun.pid" 2>/dev/null)
            log "✅ AUTORUN демон запущен (PID: $NEW_PID)"
        else
            log "❌ Ошибка запуска AUTORUN демона"
        fi
    fi
else
    log "⚠️ autorun.sh не найден"
fi

log "🛡️ Запуск мониторинга keybox..."

(
    while true; do
        if [ ! -f "/data/adb/tricky_store/keybox.xml" ]; then
            log "⚠️ keybox.xml удалён! Восстановление..."
            if [ -f "$KEY_SCRIPT" ]; then
                sh "$KEY_SCRIPT" --once >> "$LOG_FILE" 2>&1
                if [ $? -eq 0 ] && [ -f "/data/adb/tricky_store/keybox.xml" ]; then
                    log "✅ keybox.xml восстановлен"
                else
                    log "❌ Не удалось восстановить keybox.xml"
                fi
            else
                log "❌ keybox_auto.sh не найден"
            fi
        fi
        
        if [ ! -f "$LOGS_DIR/autopilot" ]; then
            log "⏹️ Автопилот отключён, мониторинг остановлен"
            break
        fi
        sleep 30
    done
) &

log "✅ Мониторинг keybox запущен (проверка каждые 30 секунд)"

log "🔍 Проверка целостности..."

if [ ! -f "/data/adb/tricky_store/keybox.xml" ]; then
    log "⚠️ keybox.xml отсутствует! Немедленное восстановление..."
    if [ -f "$KEY_SCRIPT" ]; then
        sh "$KEY_SCRIPT" --once >> "$LOG_FILE" 2>&1
    fi
else
    log "✅ keybox.xml существует"
fi

if [ ! -f "/data/adb/tricky_store/target.txt" ]; then
    log "⚠️ target.txt отсутствует! Создание..."
    if [ -f "$MODDIR/target.txt" ]; then
        cp "$MODDIR/target.txt" "/data/adb/tricky_store/target.txt" 2>/dev/null
        chmod 644 "/data/adb/tricky_store/target.txt" 2>/dev/null
        log "✅ target.txt создан"
    else
        log "❌ target.txt не найден"
    fi
else
    log "✅ target.txt существует"
fi

log "========================================="
log "✅ SERVICE.SH ЗАВЕРШЁН"
log "========================================="
log "📊 Статус:"
log "   📁 keybox_auto.sh: $([ -f "$KEY_SCRIPT" ] && echo "✅" || echo "❌")"
log "   📁 autorun.sh: $([ -f "$AUTORUN_SCRIPT" ] && echo "✅" || echo "❌")"
log "   🚀 Демон: $([ -f "$MODDIR/autorun.pid" ] && echo "✅" || echo "❌")"
log "   📦 keybox.xml: $([ -f "/data/adb/tricky_store/keybox.xml" ] && echo "✅" || echo "❌")"
log "   🟢 autopilot: $([ -f "$LOGS_DIR/autopilot" ] && echo "✅" || echo "❌")"
log "========================================="
log "📁 Логи: $LOG_FILE"
log "📁 Логи автообновления: $LOGS_DIR/autorun.log"
log "📁 Логи keybox: $MODDIR/keybox_auto.log"
log "========================================="

exit 0