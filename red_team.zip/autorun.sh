#!/system/bin/sh

MODPATH="/data/adb/modules/red_team"
LOGS_DIR="/data/adb/red_team_logs"
KEY_SCRIPT="$MODPATH/keybox_auto.sh"
LOG_FILE="$LOGS_DIR/autorun.log"
PID_FILE="$MODPATH/autorun.pid"
CHECK_INTERVAL=14400

log() {
    echo "[$(date '+%Y-%m-%d %H:%M:%S')] $1" >> "$LOG_FILE"
}

check_running() {
    if [ -f "$PID_FILE" ]; then
        local old_pid=$(cat "$PID_FILE" 2>/dev/null)
        if [ -n "$old_pid" ] && kill -0 "$old_pid" 2>/dev/null; then
            return 0
        else
            rm -f "$PID_FILE" 2>/dev/null
            return 1
        fi
    fi
    return 1
}

do_update() {
    if [ -f "$KEY_SCRIPT" ]; then
        log "🔄 Запуск обновления keybox..."
        sh "$KEY_SCRIPT" --once >> "$LOG_FILE" 2>&1
        local result=$?
        if [ $result -eq 0 ]; then
            log "✅ Обновление выполнено успешно"
        else
            log "❌ Ошибка обновления (код: $result)"
        fi
    else
        log "❌ keybox_auto.sh не найден! ($KEY_SCRIPT)"
        if [ -f "/data/adb/modules/red_team/keybox_auto.sh" ]; then
            KEY_SCRIPT="/data/adb/modules/red_team/keybox_auto.sh"
            log "✅ Найден: $KEY_SCRIPT"
            do_update
        elif [ -f "/data/adb/modules/tricky_store/keybox_auto.sh" ]; then
            KEY_SCRIPT="/data/adb/modules/tricky_store/keybox_auto.sh"
            log "✅ Найден: $KEY_SCRIPT"
            do_update
        else
            log "❌ keybox_auto.sh не найден нигде!"
        fi
    fi
}

check_network() {
    if command -v ping >/dev/null 2>&1; then
        ping -c 1 -W 2 8.8.8.8 >/dev/null 2>&1 && return 0
    fi
    if command -v curl >/dev/null 2>&1; then
        curl -s --connect-timeout 3 https://raw.githubusercontent.com >/dev/null 2>&1 && return 0
    fi
    if command -v wget >/dev/null 2>&1; then
        wget -q --spider --timeout=3 https://raw.githubusercontent.com 2>/dev/null && return 0
    fi
    return 1
}

main_loop() {
    if check_running; then
        log "⚠️ Демон уже запущен (PID: $(cat $PID_FILE 2>/dev/null))"
        exit 1
    fi
    
    echo $$ > "$PID_FILE"
    log "🚀 AUTORUN демон запущен (PID: $$)"
    log "⏱️ Интервал: ${CHECK_INTERVAL}с"
    
    if [ ! -f "$LOGS_DIR/autopilot" ]; then
        touch "$LOGS_DIR/autopilot"
        log "✅ Создан флаг autopilot в $LOGS_DIR"
    fi
    
    do_update
    
    while true; do
        date +%s > "$LOGS_DIR/daemon_heartbeat" 2>/dev/null
        
        if [ ! -f "$LOGS_DIR/autopilot" ]; then
            log "⏹️ Автопилот отключён, остановка"
            rm -f "$PID_FILE"
            exit 0
        fi
        
        if [ ! -f "$KEY_SCRIPT" ]; then
            log "❌ keybox_auto.sh не найден! ($KEY_SCRIPT)"
            if [ -f "/data/adb/modules/red_team/keybox_auto.sh" ]; then
                KEY_SCRIPT="/data/adb/modules/red_team/keybox_auto.sh"
                log "✅ Найден: $KEY_SCRIPT"
            elif [ -f "/data/adb/modules/tricky_store/keybox_auto.sh" ]; then
                KEY_SCRIPT="/data/adb/modules/tricky_store/keybox_auto.sh"
                log "✅ Найден: $KEY_SCRIPT"
            else
                log "❌ keybox_auto.sh не найден! Демон остановлен"
                rm -f "$PID_FILE"
                exit 1
            fi
        fi
        
        sleep $CHECK_INTERVAL
        
        if check_network; then
            do_update
        else
            log "🌐 Интернет недоступен, пропускаем проверку"
        fi
    done
}

stop_daemon() {
    if [ -f "$PID_FILE" ]; then
        local pid=$(cat "$PID_FILE" 2>/dev/null)
        if [ -n "$pid" ] && kill -0 "$pid" 2>/dev/null; then
            kill -TERM "$pid" 2>/dev/null
            sleep 1
            if kill -0 "$pid" 2>/dev/null; then
                kill -9 "$pid" 2>/dev/null
            fi
            log "🛑 Демон остановлен (PID: $pid)"
        fi
        rm -f "$PID_FILE" 2>/dev/null
    else
        log "⚠️ PID файл не найден, демон не запущен"
    fi
}

show_status() {
    if check_running; then
        local pid=$(cat "$PID_FILE" 2>/dev/null)
        local heartbeat=$(cat "$LOGS_DIR/daemon_heartbeat" 2>/dev/null || echo "0")
        local now=$(date +%s)
        local diff=$((now - heartbeat))
        
        echo "✅ AUTORUN демон запущен"
        echo "📌 PID: $pid"
        echo "⏱️  Интервал: ${CHECK_INTERVAL}с"
        echo "💓 Heartbeat: $diff секунд назад"
        echo "📁 Логи: $LOG_FILE"
        echo "📁 KEY_SCRIPT: $KEY_SCRIPT"
        
        if [ -f "$KEY_SCRIPT" ]; then
            echo "✅ keybox_auto.sh найден"
        else
            echo "❌ keybox_auto.sh НЕ найден!"
        fi
        
        if [ -f "$LOGS_DIR/autopilot" ]; then
            echo "🟢 Автопилот: ВКЛЮЧЁН"
        else
            echo "🔴 Автопилот: ВЫКЛЮЧЕН"
        fi
    else
        echo "❌ AUTORUN демон НЕ запущен"
    fi
}

case "$1" in
    --stop)
        stop_daemon
        ;;
    --status)
        show_status
        ;;
    --once)
        do_update
        ;;
    --restart)
        stop_daemon
        sleep 2
        main_loop
        ;;
    --help)
        echo "Использование: $0 [OPTION]"
        echo ""
        echo "  --stop      Остановить демон"
        echo "  --status    Показать статус демона"
        echo "  --once      Выполнить обновление один раз"
        echo "  --restart   Перезапустить демон"
        echo "  --help      Показать эту справку"
        ;;
    *)
        main_loop
        ;;
esac